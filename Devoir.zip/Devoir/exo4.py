
a = int(input("please enter the age of the first person : "))
b = int(input("please enter the age of the second person : "))

if a > b : print("the older age is : " , a)
elif a < b : print("the older age is : " , b)
else : print("both peaople have the same age")