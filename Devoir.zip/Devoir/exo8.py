num = int(input("enter the number : "))

if num % 3 == 0 : print("Fizz")
elif num % 5 == 0 : print("Buzz")

if (num % 5 == 0) and (num % 3 == 0) : print ("FizzBuzz")