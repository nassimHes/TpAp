

word = input("Enter a string: ")

print("*" * 30)

print(f"*{word.center(28)}*") #Center the word within 28 spaces (leaving 1 '*' on each side for the frame)

print("*" * 30)