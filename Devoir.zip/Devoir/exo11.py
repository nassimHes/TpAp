wid = int(input("enter the width of the word : "))

print("#"*wid)
