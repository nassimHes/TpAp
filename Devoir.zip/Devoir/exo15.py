
word = input("enter a word : ")

if word.__contains__('a') :
    print("'a' found ")
else : print("'a' not found ")

if word.__contains__('e') :
    print("'e' found ")
else : print("'e' not found ")

if word.__contains__('o') :
    print("'o' found ")
else : print("'o' not found ")