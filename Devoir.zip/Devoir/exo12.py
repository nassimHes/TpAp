
wid = int(input("enter the width of the word : "))
hei = int(input("enter the height of the word : "))
i = 0

while i < hei :
    print("#" * wid)
    i += 1