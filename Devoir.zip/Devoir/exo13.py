
while True :

    string = input("enter a string 'leave empty to stop': ")

    if string == "" : break

    print(string)

    print("_" * 150)