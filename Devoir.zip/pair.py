
num = int(input("enter the number : "))

if num%2 == 0 : print (num ," est pair")

else : print(num , " est impair")