
word = input("please enter a word : ")

if word.__len__()==1 :
    print("Thank you!")

else : print("there are " ,word.__len__() , "letters in the word " , word , " Thank you!")