num=int(input("entrer num :"))

if num<0 : print("la valeur absolue de " , num , "est " , -num)
else :  print("la valeur absolue de " , num , "est " , num)