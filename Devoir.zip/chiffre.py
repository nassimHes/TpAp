number = int(input("enter the number"))

if number>0 : 
    print( number , "est positif")

elif number<0 : 
    print( number , "est negatif")

else :
    print( number , "est null")

