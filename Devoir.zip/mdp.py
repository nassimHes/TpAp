mdp = input("entrer mot de passe : ")

test="test1212"

if mdp == test : print("you're a good hacker")
else : print("Incorrect")
